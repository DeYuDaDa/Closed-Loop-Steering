import os
import json
import pandas as pd
from openai import OpenAI
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import sys
import time

# API Configuration
client = OpenAI(
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com"
)

# AIME 2025 Paths
JSONL_2025_PATH = r"F:\academic\数据分析\src_api\data\aime_dataset\aime2025.jsonl"
ANS_2025_PATH = r"F:\academic\数据分析\src_api\data\aime_answer\AIME_Final_Cleaned.txt"

# Experiment Data Paths (2025)
OUR_EXP_2025 = r"F:\academic\数据分析\data\2025\aime2025_sota-ds05seed42_134237\experiment_results.json"
SEAL_2025 = r"F:\academic\数据分析\data\2025\AIME25SEALcoef_80.0_remove_bos\math_eval.jsonl"
CAA_2025 = r"F:\academic\数据分析\data\2025\AIME2025-1-caa\math_eval.jsonl"
SPHERICAL_2025 = r"F:\academic\数据分析\data\2025\AIME2025-05-spherical\math_eval.jsonl"
BAILIAN_2025 = r"F:\academic\数据分析\百炼\aime2025_batch_result.jsonl"

RAW_OUTPUT_2025 = "judge_raw_results_2025.jsonl"

# Thread-safe file writing
file_lock = threading.Lock()

def load_ground_truth_2025():
    print("Loading AIME 2025 ground truth...")
    
    # Load problems and short answers from JSONL
    gt_info = {}
    with open(JSONL_2025_PATH, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(f):
            item = json.loads(line)
            gt_info[str(idx)] = {
                'problem': item['problem'],
                'answer': item['answer'],
                'solution': "" 
            }
    
    # Load detailed solutions from Collection.txt
    if os.path.exists(ANS_2025_PATH):
        with open(ANS_2025_PATH, 'r', encoding='utf-8') as f:
            content = f.read()
            sections = content.split("------------------------------")
            for idx, sec in enumerate(sections[:30]):
                if str(idx) in gt_info:
                    sol_match = re.search(r"【Solution 1.*?】(.*?)【", sec, re.DOTALL)
                    if not sol_match:
                        sol_match = re.search(r"【Solution.*?】(.*?)(?:$|===)", sec, re.DOTALL)
                    
                    if sol_match:
                        gt_info[str(idx)]['solution'] = sol_match.group(1).strip()
                    else:
                        gt_info[str(idx)]['solution'] = sec.strip()
    
    # 在 load_ground_truth_2025 函数 return gt_info 之前加入： 
    for i in range(3): # 打印前3题检查对齐情况
        print(f"--- 问题 ID: {i} ---")
        print(f"题目: {gt_info[str(i)]['problem'][:]}...")
        print(f"提取的解答: {gt_info[str(i)]['solution'][:]}...\n")
    return gt_info

def get_judge_response_batch(tasks_chunk, retries=5):
    """Call DeepSeek API with retry logic and standardized prompt."""
    if not tasks_chunk:
        return []
    
    sample = tasks_chunk[0]
    problem = sample['problem']
    solution = sample['solution']
    answer = sample['answer']
    full_response_with_tags = sample['full_response_with_tags']
    valid_block_nums = {t['block_num'] for t in tasks_chunk}
    
    blocks_to_analyze = ""
    for t in tasks_chunk:
        blocks_to_analyze += f"--- 块号 {t['block_num']} ---\n{t['block_content']}\n\n"
    
    # Standardized Prompt aligned with 2024 script for academic consistency
    prompt = f"""你是一个数学竞赛专家评委。你需要对一个LLM生成的数学题解过程中的一组**连续思考块**（由双换行符分隔）进行打分和分类。

题目如下：
{problem}

正确解答参考：
{solution}

正确答案：
{answer}

模型生成的完整回复（已对思考块进行了XML标号）：
{full_response_with_tags}

当前正在分析的块列表：
{blocks_to_analyze}

请对上述每一个块分别进行分析，标准如下：
1. 步骤统计：统计该块内部包含了多少个小的推理步骤，并指出其中正确和错误的步数。
2. 块分类：请将该块归类为以下四种之一：
   - 正确推理过程
   - 错误推理过程
   - 从正确推理变成错误推理
   - 从错误推理修正回正确推理

请务必以JSON数组格式输出，数组中每个对象对应一个块，按块号顺序排列，不要包含任何多余文字：
[
  {{
    "block_num": int,
    "total_sub_steps": int,
    "correct_sub_steps": int,
    "incorrect_sub_steps": int,
    "classification": "..."
  }},
  ...
]
"""
    wait_time = 1
    for attempt in range(retries):
        try:
            response = client.chat.completions.create(
                model="deepseek-v4-flash",
                messages=[
                    {"role": "system", "content": "You are a professional math judge."},
                    {"role": "user", "content": prompt},
                ],
                stream=False,
                extra_body={"thinking": {"type": "enabled"}}
            )
            content = response.choices[0].message.content
            match = re.search(r'\[.*\]', content, re.DOTALL)
            if match:
                res_list = json.loads(match.group())
            else:
                res_list = json.loads(content)
            
            with file_lock:
                with open(RAW_OUTPUT_2025, 'a', encoding='utf-8') as f:
                    for res in res_list:
                        b_num = res.get('block_num')
                        if b_num in valid_block_nums:
                            save_item = {
                                "group": sample['group'],
                                "problem_id": sample['problem_id'],
                                "block_num": b_num,
                                "result": res
                            }
                            f.write(json.dumps(save_item, ensure_ascii=False) + "\n")
            return res_list
        except Exception as e:
            if "429" in str(e):
                print(f"      [429 Rate Limit] Retrying in {wait_time}s... (Attempt {attempt+1}/{retries})")
                time.sleep(wait_time)
                wait_time *= 2
            else:
                print(f"      [Error] API call failed for Problem {sample['problem_id']}: {e}")
                break
    return None

def process_single_problem(problem_id, generation, gt_info, group_name, processed_blocks, api_executor):
    if not generation: return
    blocks = [b.strip() for b in generation.split('\n\n') if b.strip()]
    tagged_response = ""
    for i, block in enumerate(blocks):
        tagged_response += f"<block_{i+1}>\n{block}\n</block_{i+1}>\n\n"
    
    all_tasks = []
    for i, block in enumerate(blocks):
        block_num = i + 1
        if (group_name, problem_id, block_num) in processed_blocks:
            continue
        all_tasks.append({
            'group': group_name,
            'problem_id': problem_id,
            'problem': gt_info['problem'],
            'solution': gt_info['solution'],
            'answer': gt_info['answer'],
            'full_response_with_tags': tagged_response,
            'block_num': block_num,
            'block_content': block
        })
    
    if not all_tasks: return
    
    batch_size = 10
    first_batch = all_tasks[:batch_size]
    print(f"      [PRIME] {group_name} ID {problem_id} (Blocks 1-{len(first_batch)})")
    get_judge_response_batch(first_batch)
    
    time.sleep(5)
    
    remaining = all_tasks[batch_size:]
    if remaining:
        chunks = [remaining[i:i+batch_size] for i in range(0, len(remaining), batch_size)]
        print(f"      [ASYNC] Submitting {len(chunks)} chunks for {group_name} ID {problem_id}")
        for chunk in chunks:
            api_executor.submit(get_judge_response_batch, chunk)

def run_judge_2025():
    gt = load_ground_truth_2025()
    # exit()
    processed = set()
    if os.path.exists(RAW_OUTPUT_2025):
        with open(RAW_OUTPUT_2025, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    d = json.loads(line)
                    processed.add((d['group'], d['problem_id'], d['block_num']))
                except: pass
    
    print(f"Resuming AIME 2025: {len(processed)} blocks processed.")
    
    with ThreadPoolExecutor(max_workers=30) as api_exec:
        with ThreadPoolExecutor(max_workers=10) as prob_exec:
            tasks = []
            
            if os.path.exists(OUR_EXP_2025):
                with open(OUR_EXP_2025, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for grp in ["Dynamic_Spherical", "Baseline", "Continuous"]:
                    if grp in data:
                        for p in data[grp]['per_problem']:
                            pid = str(p['id'])
                            if pid in gt:
                                tasks.append((pid, p['full_response'], gt[pid], grp))
            
            for grp, path in [("SEAL_Baseline", SEAL_2025), ("CAA", CAA_2025), ("Spherical_Steering", SPHERICAL_2025)]:
                if os.path.exists(path):
                    with open(path, 'r', encoding='utf-8') as f:
                        for idx, line in enumerate(f):
                            pid = str(idx)
                            if pid in gt:
                                item = json.loads(line)
                                gen = item['model_generation'][0]
                                tasks.append((pid, gen, gt[pid], grp))
            
            if os.path.exists(BAILIAN_2025):
                with open(BAILIAN_2025, 'r', encoding='utf-8') as f:
                    for line in f:
                        item = json.loads(line)
                        pid = str(item['custom_id'].split('-')[-1])
                        if pid in gt:
                            tasks.append((pid, item.get('reasoning_content', ''), gt[pid], "Bailian"))

            print(f"Total problems to process: {len(tasks)}")
            futures = [prob_exec.submit(process_single_problem, *t, processed, api_exec) for t in tasks]
            for f in as_completed(futures): f.result()

def run_stats_2025():
    import judge_analytics
    judge_analytics.print_full_report(RAW_OUTPUT_2025, baseline_group_name="SEAL_Baseline")

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "judge"
    if mode == "stats": run_stats_2025()
    else:
        run_judge_2025()
        run_stats_2025()

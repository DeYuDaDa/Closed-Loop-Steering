"""
Shared analytics module for LLM-as-Judge evaluation.
Used by both llm_as_judge.py (2024) and llm_as_judge_2025.py (2025).
"""

import json
import re
from collections import defaultdict

# Classification string constants (must match judge prompts)
CLS_CORRECT = "正确推理过程"
CLS_INCORRECT = "错误推理过程"
CLS_C2E = "从正确推理变成错误推理"
CLS_E2C = "从错误推理修正回正确推理"

ALL_ERROR_TYPES = {CLS_INCORRECT, CLS_C2E}
ALL_CORRECT_TYPES = {CLS_CORRECT, CLS_E2C}


def load_unique_blocks(raw_output_path):
    """Load and deduplicate raw judge results. Returns dict keyed by (group, problem_id, block_num)."""
    unique_blocks = {}
    with open(raw_output_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                key = (data['group'], data['problem_id'], data['block_num'])
                unique_blocks[key] = data
            except:
                continue
    return unique_blocks


def group_by_problem(unique_blocks):
    """
    Organise blocks into: {group: {problem_id: [sorted block dicts]}}
    """
    grouped = defaultdict(lambda: defaultdict(list))
    for (grp, pid, bnum), data in unique_blocks.items():
        grouped[grp][pid].append(data)
    # Sort each problem's blocks by block_num
    for grp in grouped:
        for pid in grouped[grp]:
            grouped[grp][pid].sort(key=lambda x: x['block_num'])
    return grouped


# ---------------------------------------------------------------------------
# Core metrics
# ---------------------------------------------------------------------------

CLS_MAPPING = {
    # 正确推理过程
    "正确推理过程": "正确推理过程",
    "correct reasoning process": "正确推理过程",
    "correct推理过程": "正确推理过程",      
    "correct inference process": "正确推理过程",
    "Correct reasoning process": "正确推理过程",
    "correct_reasoning": "正确推理过程",
    "correct reasoning": "正确推理过程",
    "Correct Reasoning": "正确推理过程",
    "correct": "正确推理过程",              
    
    # 错误推理过程
    "错误推理过程": "错误推理过程",
    "incorrect reasoning process": "错误推理过程",
    "incorrect_reasoning": "错误推理过程",
    "errorneous reasoning process": "错误推理过程",
    "incorrect": "错误推理过程",
    "Incorrect Reasoning": "错误推理过程",
    "erroneous reasoning process": "错误推理过程",  
    
    # 从正确推理变成错误推理
    "从正确推理变成错误推理": "从正确推理变成错误推理",
    "从正确变成错误": "从正确推理变成错误推理",
    "correct to incorrect": "从正确推理变成错误推理",
    "from correct to incorrect": "从正确推理变成错误推理",
    "correct_to_incorrect": "从正确推理变成错误推理",
    "Correct to Incorrect": "从正确推理变成错误推理",
    "from correct to incorrect reasoning": "从正确推理变成错误推理",
    
    # 从错误推理修正回正确推理
    "从错误推理修正回正确推理": "从错误推理修正回正确推理",
    "从错误推理变成正确推理": "从错误推理修正回正确推理",
    "从错误推理变为正确推理": "从错误推理修正回正确推理",
    "从错误修正回正确": "从错误推理修正回正确推理",
    "从错误修正回正确推理": "从错误推理修正回正确推理",
    "从错误推理修改回正确推理": "从错误推理修正回正确推理",
    "incorrect to correct": "从错误推理修正回正确推理",
    "incorrect_to_correct": "从错误推理修正回正确推理",
    "Incorrect to Correct": "从错误推理修正回正确推理",
    "从错误修正回正确推理过程": "从错误推理修正回正确推理",
}

def normalize_cls(raw_cls):
    """Normalize raw classification string using the provided mapping."""
    if not raw_cls:
        return "Unknown"
    # Try exact match, then case-insensitive match
    res = CLS_MAPPING.get(raw_cls)
    if not res:
        res = CLS_MAPPING.get(raw_cls.lower().strip())
    return res if res else raw_cls

def compute_core_metrics(blocks_list):
    """
    Given a flat list of block dicts (across any scope), compute:
    - counts for each of the 4 classifications
    - Recovery Rate, Degradation Rate, Advantage Ratio
    """
    counts = {CLS_CORRECT: 0, CLS_INCORRECT: 0, CLS_C2E: 0, CLS_E2C: 0}
    for b in blocks_list:
        raw_c = b['result'].get('classification', '')
        c = normalize_cls(raw_c)
        if c in counts:
            counts[c] += 1

    total_error_contexts = counts[CLS_INCORRECT] + counts[CLS_E2C]  
    total_correct_contexts = counts[CLS_CORRECT] + counts[CLS_C2E]  

    recovery_rate = counts[CLS_E2C] / total_error_contexts if total_error_contexts > 0 else float('nan')
    degradation_rate = counts[CLS_C2E] / total_correct_contexts if total_correct_contexts > 0 else float('nan')
    advantage_ratio = recovery_rate / degradation_rate if (degradation_rate and degradation_rate > 0) else float('nan')

    total = sum(counts.values())
    correct_steps = sum(b['result'].get('correct_sub_steps', 0) for b in blocks_list)
    incorrect_steps = sum(b['result'].get('incorrect_sub_steps', 0) for b in blocks_list)
    step_acc = correct_steps / (correct_steps + incorrect_steps) if (correct_steps + incorrect_steps) > 0 else float('nan')

    return {
        'total_blocks': total,
        'correct_steps': correct_steps,
        'incorrect_steps': incorrect_steps,
        'step_accuracy': step_acc,
        'counts': counts,
        'total_error_contexts': total_error_contexts,
        'total_correct_contexts': total_correct_contexts,
        'recovery_rate': recovery_rate,
        'degradation_rate': degradation_rate,
        'advantage_ratio': advantage_ratio,
    }


# ---------------------------------------------------------------------------
# Dimension 1: Temporal / Depth Analysis
# ---------------------------------------------------------------------------

def compute_temporal_analysis(problem_blocks_dict):
    """
    problem_blocks_dict: {problem_id: [sorted block dicts]}
    Returns {'early': metrics, 'mid': metrics, 'late': metrics}
    """
    early_blocks, mid_blocks, late_blocks = [], [], []

    for pid, blocks in problem_blocks_dict.items():
        N = len(blocks)
        if N == 0:
            continue
        n_early = max(1, min(10, int(round(0.15 * N))))
        n_late = max(1, min(15, int(round(0.20 * N))))

        # Guard: ensure early + late <= N
        if n_early + n_late >= N:
            n_late = max(0, N - n_early)

        early_blocks.extend(blocks[:n_early])
        late_blocks.extend(blocks[N - n_late:] if n_late > 0 else [])
        mid_blocks.extend(blocks[n_early: N - n_late] if n_late > 0 else blocks[n_early:])

    return {
        'early': compute_core_metrics(early_blocks),
        'mid': compute_core_metrics(mid_blocks),
        'late': compute_core_metrics(late_blocks),
    }


# ---------------------------------------------------------------------------
# Dimension 2: Error Persistence (Trajectory Analysis)
# ---------------------------------------------------------------------------

def compute_error_persistence(problem_blocks_dict):
    """
    Returns a list of all error-run lengths (consecutive error blocks).
    Also returns summary statistics.
    """
    all_run_lengths = []

    for pid, blocks in problem_blocks_dict.items():
        run = 0
        for b in blocks:
            raw_c = b['result'].get('classification', '')
            c = normalize_cls(raw_c)
            if c in ALL_ERROR_TYPES:
                run += 1
            else:
                if run > 0:
                    all_run_lengths.append(run)
                run = 0
        if run > 0:
            all_run_lengths.append(run)

    if not all_run_lengths:
        return {'runs': [], 'mean': float('nan'), 'max': 0,
                'dist': {}, 'pct_immediate': float('nan')}

    dist = defaultdict(int)
    for r in all_run_lengths:
        bucket = r if r <= 5 else '6+'
        dist[str(bucket)] += 1

    pct_immediate = dist['1'] / len(all_run_lengths) if all_run_lengths else float('nan')
    mean_run = sum(all_run_lengths) / len(all_run_lengths)
    max_run = max(all_run_lengths)

    return {
        'runs': all_run_lengths,
        'mean': mean_run,
        'max': max_run,
        'dist': dict(dist),
        'pct_immediate': pct_immediate,
    }


# ---------------------------------------------------------------------------
# Dimension 3: Sub-step Severity Index
# ---------------------------------------------------------------------------

def compute_severity(blocks_list):
    """
    For blocks classified as erroneous (INCORRECT or C2E),
    compute severity = incorrect_steps / total_steps.
    """
    severities = []
    for b in blocks_list:
        raw_c = b['result'].get('classification', '')
        c = normalize_cls(raw_c)
        if c in ALL_ERROR_TYPES:
            total = b['result'].get('total_sub_steps', 0)
            incorrect = b['result'].get('incorrect_sub_steps', 0)
            if total > 0:
                severities.append(incorrect / total)

    if not severities:
        return {'mean': float('nan'), 'median': float('nan'), 'n': 0,
                'pct_total_collapse': float('nan')}

    severities_sorted = sorted(severities)
    n = len(severities_sorted)
    mean_sev = sum(severities_sorted) / n
    median_sev = severities_sorted[n // 2]
    pct_total_collapse = sum(1 for s in severities_sorted if s >= 0.9) / n

    return {
        'mean': mean_sev,
        'median': median_sev,
        'n': n,
        'pct_total_collapse': pct_total_collapse,
    }


# ---------------------------------------------------------------------------
# Dimension 4: Problem-Level Heterogeneity
# ---------------------------------------------------------------------------

def compute_problem_heterogeneity(grouped_by_group, baseline_group_name):
    """
    Compute per-problem error metrics across all groups.
    Uses baseline_group_name to determine difficulty tiers.
    Returns per-problem stats and tier breakdown.
    """
    # Collect per-problem metrics for each group
    per_problem_metrics = defaultdict(dict)

    for grp, prob_dict in grouped_by_group.items():
        for pid, blocks in prob_dict.items():
            m = compute_core_metrics(blocks)
            per_problem_metrics[pid][grp] = m

    # Determine difficulty tiers from baseline
    baseline_error_rates = {}
    for pid, grp_map in per_problem_metrics.items():
        if baseline_group_name in grp_map:
            m = grp_map[baseline_group_name]
            total = m['total_blocks']
            err = m['counts'].get(CLS_INCORRECT, 0) + m['counts'].get(CLS_C2E, 0)
            baseline_error_rates[pid] = err / total if total > 0 else 0.0

    if not baseline_error_rates:
        return {'per_problem': per_problem_metrics, 'tiers': {}, 'baseline_rates': {}}

    sorted_pids = sorted(baseline_error_rates.keys(), key=lambda p: baseline_error_rates[p])
    n = len(sorted_pids)
    easy_pids = set(sorted_pids[:n // 3])
    hard_pids = set(sorted_pids[2 * n // 3:])
    medium_pids = set(sorted_pids[n // 3: 2 * n // 3])

    tier_map = {pid: 'easy' for pid in easy_pids}
    tier_map.update({pid: 'medium' for pid in medium_pids})
    tier_map.update({pid: 'hard' for pid in hard_pids})

    return {
        'per_problem': per_problem_metrics,
        'tiers': tier_map,
        'baseline_rates': baseline_error_rates,
    }


# ---------------------------------------------------------------------------
# Pretty Print
# ---------------------------------------------------------------------------

def fmt(val, fmt_str=".2%"):
    if val != val:  # NaN check
        return "N/A"
    return format(val, fmt_str)


def print_full_report(raw_output_path, baseline_group_name=None, save_jsonl=True):
    """
    Full analysis report. baseline_group_name is used for heterogeneity tiers.
    If save_jsonl is True, saves results to {raw_output_path}_analysis.jsonl
    """
    unique_blocks = load_unique_blocks(raw_output_path)
    if not unique_blocks:
        print("No data found.")
        return

    grouped = group_by_problem(unique_blocks)
    
    print("=" * 70)
    print("  LLM-AS-JUDGE ANALYSIS REPORT")
    print("=" * 70)

    # Prepare for saving
    analysis_records = []
    
    # ── Per-Group Analysis ───────────────────────────────────────────────────
    print("\n【1】Core Metrics per Group")
    print("-" * 70)
    
    all_group_stats = {}
    
    for grp in sorted(grouped.keys()):
        # Gather all blocks for this group
        group_blocks = [b for pid_blocks in grouped[grp].values() for b in pid_blocks]
        
        # 1. Core
        m = compute_core_metrics(group_blocks)
        
        # 2. Temporal
        ta = compute_temporal_analysis(grouped[grp])
        
        # 3. Persistence
        ep = compute_error_persistence(grouped[grp])
        
        # 4. Severity
        sv = compute_severity(group_blocks)
        
        # Store in dict for saving
        group_summary = {
            "group": grp,
            "core": m,
            "temporal": ta,
            "persistence": {k: v for k, v in ep.items() if k != 'runs'}, # Skip raw runs
            "severity": sv
        }
        all_group_stats[grp] = group_summary
        analysis_records.append(group_summary)

        # Print Core
        c = m['counts']
        print(f"\n  ▶ {grp}  ({m['total_blocks']} blocks, {len(grouped[grp])} problems)")
        print(f"    Step Accuracy   : {fmt(m['step_accuracy'])}")
        print(f"    {CLS_CORRECT}: {c[CLS_CORRECT]}  |  {CLS_INCORRECT}: {c[CLS_INCORRECT]}")
        print(f"    {CLS_C2E}: {c[CLS_C2E]}  |  {CLS_E2C}: {c[CLS_E2C]}")
        print(f"    ─ Recovery Rate (E→C / All-Error-Contexts)   : {fmt(m['recovery_rate'])}")
        print(f"    ─ Degradation Rate (C→E / All-Correct-Contexts): {fmt(m['degradation_rate'])}")
        print(f"    ─ Transition Advantage Ratio                  : {fmt(m['advantage_ratio'], '.3f')}")

    # ── Dimension 1: Temporal Analysis (Print) ───────────────────────────────
    print("\n\n【2】Temporal / Depth Analysis  (Early | Mid | Late)")
    print("-" * 70)
    header = f"  {'Group':<25} {'Stage':<8} {'Blks':>6} {'StepAcc':>8} {'RecovRate':>10} {'DegRate':>10} {'AdvRatio':>10}"
    print(header)
    for grp in sorted(all_group_stats.keys()):
        ta = all_group_stats[grp]['temporal']
        for stage in ['early', 'mid', 'late']:
            m = ta[stage]
            print(f"  {grp:<25} {stage:<8} {m['total_blocks']:>6} "
                  f"{fmt(m['step_accuracy']):>8} "
                  f"{fmt(m['recovery_rate']):>10} "
                  f"{fmt(m['degradation_rate']):>10} "
                  f"{fmt(m['advantage_ratio'], '.3f'):>10}")

    # ── Dimension 2: Error Persistence (Print) ───────────────────────────────
    print("\n\n【3】Error Persistence (Trajectory Analysis)")
    print("-" * 70)
    for grp in sorted(all_group_stats.keys()):
        ep = all_group_stats[grp]['persistence']
        dist_str = "  ".join(f"len={k}: {v}" for k, v in sorted(ep['dist'].items()))
        print(f"\n  ▶ {grp}")
        print(f"    Mean error-run length : {fmt(ep['mean'], '.2f')}")
        print(f"    Max error-run length  : {ep['max']}")
        print(f"    Immediate recovery (len=1): {fmt(ep['pct_immediate'])}")
        print(f"    Distribution          : {dist_str}")

    # ── Dimension 3: Severity Index (Print) ──────────────────────────────────
    print("\n\n【4】Sub-step Error Severity Index")
    print("-" * 70)
    print(f"  {'Group':<25} {'N':>6} {'Mean Sev':>10} {'Median Sev':>12} {'Total Collapse%':>16}")
    for grp in sorted(all_group_stats.keys()):
        sv = all_group_stats[grp]['severity']
        print(f"  {grp:<25} {sv['n']:>6} {fmt(sv['mean']):>10} {fmt(sv['median']):>12} {fmt(sv['pct_total_collapse']):>16}")

    # ── Dimension 4: Heterogeneity ───────────────────────────────────────────
    print("\n\n【5】Problem-Level Heterogeneity")
    print("-" * 70)
    bsl = baseline_group_name or (sorted(grouped.keys())[0] if grouped else None)
    het = compute_problem_heterogeneity(grouped, bsl)

    tier_results = {}
    if het['tiers']:
        tiers = het['tiers']
        for tier_name in ['easy', 'medium', 'hard']:
            tier_pids = [p for p, t in tiers.items() if t == tier_name]
            if not tier_pids: continue
            
            print(f"\n  Tier: {tier_name.upper()} ({len(tier_pids)} problems, baseline = {bsl})")
            tier_results[tier_name] = {}
            
            for grp in sorted(grouped.keys()):
                tier_blocks = []
                for pid in tier_pids:
                    if pid in grouped[grp]: tier_blocks.extend(grouped[grp][pid])
                if not tier_blocks: continue
                m = compute_core_metrics(tier_blocks)
                tier_results[tier_name][grp] = m
                print(f"    {grp:<25}  RecovRate={fmt(m['recovery_rate'])}  DegRate={fmt(m['degradation_rate'])}  AdvRatio={fmt(m['advantage_ratio'], '.3f')}")
    
    # Save results
    if save_jsonl:
        out_path = raw_output_path.replace(".jsonl", "") + "_analysis.jsonl"
        with open(out_path, 'w', encoding='utf-8') as f:
            # Metadata
            f.write(json.dumps({"type": "metadata", "baseline": bsl, "problems": len(grouped)}, ensure_ascii=False) + "\n")
            # Group stats
            for rec in analysis_records:
                f.write(json.dumps({"type": "group_stats", **rec}, ensure_ascii=False) + "\n")
            # Tier stats
            if tier_results:
                f.write(json.dumps({"type": "tier_stats", "tiers": tier_results}, ensure_ascii=False) + "\n")
        print(f"\n[Success] Analysis results saved to: {out_path}")

    print("\n" + "=" * 70)

import os
import json
import pandas as pd
from openai import OpenAI
from tqdm import tqdm
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import sys
import time

# API Configuration
client = OpenAI(
    api_key=os.environ.get('DEEPSEEK_API_KEY'),
    base_url="https://api.deepseek.com"
)

# Paths
PARQUET_PATH = r"F:\academic\数据分析\src_api\data\aime_answer\aime_2024_problems.parquet"
JSONL_ORIGINAL_PATH = r"F:\academic\数据分析\src_api\data\aime_dataset\aime2024.jsonl"
OUR_EXP_PATH = r"F:\academic\数据分析\data\2024\AIME2024_ds-03-seed42_005106\experiment_results.json"
BASELINE_EXP_PATH = r"F:\academic\数据分析\data\2024\AIME24SEAL-coef_80.0_remove_bos\math_eval.jsonl"
CAA_EXP_PATH = r"F:\academic\数据分析\data\2024\AIME2024-1-caa\math_eval.jsonl"
SPHERICAL_EXP_PATH = r"F:\academic\数据分析\data\2024\AIME2024-05-spherical\math_eval.jsonl"
BAILIAN_EXP_PATH = r"F:\academic\数据分析\百炼\aime2024_batch_result.jsonl"
RAW_OUTPUT_PATH = "judge_raw_results.jsonl"

# Thread-safe file writing
file_lock = threading.Lock()

def get_parquet_id(jsonl_id):
    """Manual mapping as confirmed by user: 60-89 -> 2024-I-1...2024-II-15"""
    try:
        idx = int(jsonl_id) - 60
        if 0 <= idx < 15:
            return f"2024-I-{idx + 1}"
        elif 15 <= idx < 30:
            return f"2024-II-{idx - 15 + 1}"
    except:
        pass
    return None

def normalize_text(text):
    return re.sub(r'\s+', '', str(text)).strip()

def load_ground_truth():
    print("Loading ground truth data...")
    df_gt = pd.read_parquet(PARQUET_PATH)
    gt_by_id = {}
    for _, row in df_gt.iterrows():
        gt_by_id[row['ID']] = {
            'solution': row['Solution'],
            'answer': row['Answer'],
            'problem': row['Problem']
        }
    
    final_gt = {}
    ordered_ids = []
    with open(JSONL_ORIGINAL_PATH, 'r', encoding='utf-8') as f:
        for line in f:
            item = json.loads(line)
            jid = str(item['id'])
            ordered_ids.append(jid)
            pid = get_parquet_id(jid)
            if pid in gt_by_id:
                final_gt[jid] = gt_by_id[pid]
            else:
                print(f"Warning: Manual mapping failed for ID {jid} -> Parquet ID {pid}")
    return final_gt, ordered_ids

def debug_ground_truth_alignment():
    """调试函数：检查 2024 版本的 ID 映射和数据完整性"""
    print("\n" + "="*50)
    print("开始调试：2024 Ground Truth 数据对齐检查")
    print("="*50)
    
    gt, ordered_ids = load_ground_truth()
    
    if not gt:
        print("错误：未加载到任何 Ground Truth 数据！请检查路径。")
        return

    print(f"成功加载题目数量: {len(gt)}")
    print(f"预期 ID 范围: 60 - 89")
    
    # 抽样检查：检查第一题、中间题（跨越 I 和 II 的分界点）、最后一题
    sample_ids = [ordered_ids[0], "74", "75", ordered_ids[-1]]
    
    for jid in sample_ids:
        if jid not in gt:
            print(f"\n[错误] 无法在 GT 中找到 JSONL ID: {jid}")
            continue
            
        data = gt[jid]
        pid = get_parquet_id(jid)
        
        print(f"\n--- 样本检查: JSONL_ID({jid}) -> Parquet_ID({pid}) ---")
        print(f"【题干摘要】: {data['problem'][:]}")
        print(f"【参考答案】: {data['answer']}")
        print(f"【解法】: {data['solution'][:]}")
        print(f"【解法长度】: {len(str(data['solution']))} 字符")
        
        if not data['solution'] or len(str(data['solution'])) < 10:
            print("  [警告] 解法内容似乎过短或缺失！")
        if not data['problem']:
            print("  [错误] 题干内容为空！")

    print("\n" + "="*50)
    print("调试结束")
    print("="*50 + "\n")

def get_judge_response_batch(tasks_chunk, retries=5):
    """Call DeepSeek API to judge a batch of blocks (up to 10) with retry logic."""
    if not tasks_chunk:
        return []
    
    sample = tasks_chunk[0]
    problem = sample['problem']
    solution = sample['solution']
    answer = sample['answer']
    full_response_with_tags = sample['full_response_with_tags']
    valid_block_nums = {t['block_num'] for t in tasks_chunk}
    
    blocks_to_analyze = ""
    for t in tasks_chunk:
        blocks_to_analyze += f"--- 块号 {t['block_num']} ---\n{t['block_content']}\n\n"
    
    prompt = f"""你是一个数学竞赛专家评委。你需要对一个LLM生成的数学题解过程中的一组**连续思考块**（由双换行符分隔）进行打分和分类。

题目如下：
{problem}

正确解答参考：
{solution}

正确答案：
{answer}

模型生成的完整回复（已对思考块进行了XML标号）：
{full_response_with_tags}

当前正在分析的块列表：
{blocks_to_analyze}

请对上述每一个块分别进行分析，标准如下：
1. 步骤统计：统计该块内部包含了多少个小的推理步骤，并指出其中正确和错误的步数。
2. 块分类：请将该块归类为以下四种之一：
   - 正确推理过程
   - 错误推理过程
   - 从正确推理变成错误推理
   - 从错误推理修正回正确推理

请务必以JSON数组格式输出，数组中每个对象对应一个块，按块号顺序排列，不要包含任何多余文字：
[
  {{
    "block_num": int,
    "total_sub_steps": int,
    "correct_sub_steps": int,
    "incorrect_sub_steps": int,
    "classification": "..."
  }},
  ...
]
"""
    wait_time = 1
    for attempt in range(retries):
        try:
            response = client.chat.completions.create(
                model="deepseek-v4-flash",
                messages=[
                    {"role": "system", "content": "You are a professional math judge."},
                    {"role": "user", "content": prompt},
                ],
                stream=False,
                extra_body={"thinking": {"type": "enabled"}}
            )
            content = response.choices[0].message.content
            match = re.search(r'\[.*\]', content, re.DOTALL)
            if match:
                res_list = json.loads(match.group())
            else:
                res_list = json.loads(content)
            
            with file_lock:
                with open(RAW_OUTPUT_PATH, 'a', encoding='utf-8') as f:
                    for res in res_list:
                        b_num = res.get('block_num')
                        if b_num in valid_block_nums:
                            save_item = {
                                "group": sample['group'],
                                "problem_id": sample['problem_id'],
                                "block_num": b_num,
                                "result": res
                            }
                            f.write(json.dumps(save_item, ensure_ascii=False) + "\n")
            
            return res_list
        except Exception as e:
            if "429" in str(e):
                print(f"      [429 Rate Limit] Problem {sample['problem_id']} in {sample['group']}: Retrying in {wait_time}s... (Attempt {attempt+1}/{retries})")
                time.sleep(wait_time)
                wait_time *= 2
            else:
                print(f"      [Error] API call failed for Problem {sample['problem_id']} in {sample['group']}: {e}")
                break
    return None

def process_single_problem(problem_id, generation, gt_info, group_name, processed_blocks, api_executor):
    """Worker function for a single problem: Prime -> Wait 5s -> Concurrently process rest."""
    if not generation: return
    blocks = [b.strip() for b in generation.split('\n\n') if b.strip()]
    tagged_response = ""
    for i, block in enumerate(blocks):
        tagged_response += f"<block_{i+1}>\n{block}\n</block_{i+1}>\n\n"
    
    all_tasks = []
    for i, block in enumerate(blocks):
        block_num = i + 1
        if (group_name, problem_id, block_num) in processed_blocks:
            continue
        all_tasks.append({
            'group': group_name,
            'problem_id': problem_id,
            'problem': gt_info['problem'],
            'solution': gt_info['solution'],
            'answer': gt_info['answer'],
            'full_response_with_tags': tagged_response,
            'block_num': block_num,
            'block_content': block
        })
    
    if not all_tasks:
        return

    batch_size = 10
    first_batch = all_tasks[:batch_size]
    
    # 1. Synchronously prime the cache for THIS problem
    print(f"      [PRIME] Problem {problem_id} in {group_name}: blocks {first_batch[0]['block_num']}-{first_batch[-1]['block_num']}...")
    get_judge_response_batch(first_batch)
    
    # 2. Wait 5 seconds as requested by user to ensure cache is ready
    time.sleep(5)
    
    # 3. Concurrently submit remaining chunks to the GLOBAL api_executor
    remaining_tasks = all_tasks[batch_size:]
    if remaining_tasks:
        chunks = [remaining_tasks[i:i + batch_size] for i in range(0, len(remaining_tasks), batch_size)]
        print(f"      [ASYNC] Submitting {len(chunks)} chunks for Problem {problem_id} in {group_name}...")
        for chunk in chunks:
            api_executor.submit(get_judge_response_batch, chunk)

def get_processed_blocks():
    processed = set()
    if os.path.exists(RAW_OUTPUT_PATH):
        with open(RAW_OUTPUT_PATH, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    processed.add((data['group'], data['problem_id'], data['block_num']))
                except:
                    continue
    return processed

def run_judge():
    gt, ordered_ids = load_ground_truth()
    processed_blocks = get_processed_blocks()
    print(f"Resuming: {len(processed_blocks)} blocks already processed.")
    
    max_api_workers = 30  # Max concurrent API requests
    max_problem_workers = 10 # Max problems being primed/processed at once
    
    if not os.path.exists(RAW_OUTPUT_PATH):
        with open(RAW_OUTPUT_PATH, 'w', encoding='utf-8') as f:
            pass

    with ThreadPoolExecutor(max_workers=max_api_workers) as api_executor:
        with ThreadPoolExecutor(max_workers=max_problem_workers) as problem_executor:
            
            all_problem_tasks = []

            # 1. Our Experiment (JSON format)
            if os.path.exists(OUR_EXP_PATH):
                with open(OUR_EXP_PATH, 'r', encoding='utf-8') as f:
                    our_data = json.load(f)
                for model_group in ["Dynamic_Spherical", "Baseline", "Continuous"]:
                    if model_group not in our_data: continue
                    for prob in our_data[model_group]['per_problem']:
                        pid = str(prob['id'])
                        if pid in gt:
                            all_problem_tasks.append((pid, prob['full_response'], gt[pid], model_group))
            
            # 2. JSONL Experiment Groups
            jsonl_groups = [
                ("SEAL_Baseline", BASELINE_EXP_PATH),
                ("CAA", CAA_EXP_PATH),
                ("Spherical_Steering", SPHERICAL_EXP_PATH)
            ]
            for group_name, file_path in jsonl_groups:
                if os.path.exists(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        for idx, line in enumerate(f):
                            if idx >= len(ordered_ids): break
                            pid = ordered_ids[idx]
                            if pid in gt:
                                item = json.loads(line)
                                gen = item['model_generation'][0]
                                all_problem_tasks.append((pid, gen, gt[pid], group_name))
            
            # 3. Bailian Experiment
            if os.path.exists(BAILIAN_EXP_PATH):
                with open(BAILIAN_EXP_PATH, 'r', encoding='utf-8') as f:
                    for line in f:
                        try:
                            item = json.loads(line)
                            cid = item['custom_id']
                            pid = str(cid.split('-')[-1])
                            if pid in gt:
                                tasks_chunk = item.get('reasoning_content', '')
                                all_problem_tasks.append((pid, tasks_chunk, gt[pid], "Bailian"))
                        except: pass

            print(f"\nStarting concurrent processing for {len(all_problem_tasks)} problems...")
            futures = [problem_executor.submit(process_single_problem, *t, processed_blocks, api_executor) for t in all_problem_tasks]
            
            for future in as_completed(futures):
                future.result()

    print(f"\nJudging complete. Results in {RAW_OUTPUT_PATH}")

def run_stats():
    import judge_analytics
    judge_analytics.print_full_report(RAW_OUTPUT_PATH, baseline_group_name="SEAL_Baseline")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "stats":
            run_stats()
        elif cmd == "judge":
            run_judge()
        elif cmd == "debug":  # 新增调试入口
            debug_ground_truth_alignment()
        else:
            print("Usage: python script.py [judge|stats|debug]")
    else:
        # 默认流程：先跑调试，确认没问题后再判卷
        debug_ground_truth_alignment()
        
        # 如果你只想默认运行判卷，可以取消下面的注释
        # run_judge()
        # run_stats()

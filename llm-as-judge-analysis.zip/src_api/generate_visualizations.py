import json
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from math import pi
import matplotlib
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
from collections import defaultdict

# Configure style
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial']  # Support Chinese
plt.rcParams['axes.unicode_minus'] = False
sns.set_theme(style="whitegrid")

# Paths
PATH_2024_ANALYSIS = r"f:\academic\数据分析\src_api\judge_raw_results_analysis.jsonl"
PATH_2025_ANALYSIS = r"f:\academic\数据分析\src_api\judge_raw_results_2025_analysis.jsonl"
PATH_2024_RAW = r"f:\academic\数据分析\src_api\judge_raw_results.jsonl"
PATH_2025_RAW = r"f:\academic\数据分析\src_api\judge_raw_results_2025.jsonl"

OUTPUT_DIR = "visualizations"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Normalization Mapping
CLS_MAPPING = {
    "正确推理过程": "Correct", "correct reasoning process": "Correct", "correct推理过程": "Correct",
    "correct inference process": "Correct", "Correct reasoning process": "Correct", "correct_reasoning": "Correct",
    "correct reasoning": "Correct", "Correct Reasoning": "Correct", "correct": "Correct",
    "错误推理过程": "Incorrect", "incorrect reasoning process": "Incorrect", "incorrect_reasoning": "Incorrect",
    "errorneous reasoning process": "Incorrect", "incorrect": "Incorrect", "Incorrect Reasoning": "Incorrect",
    "erroneous reasoning process": "Incorrect",
    "从正确推理变成错误推理": "C2E", "从正确变成错误": "C2E", "correct to incorrect": "C2E",
    "from correct to incorrect": "C2E", "correct_to_incorrect": "C2E", "Correct to Incorrect": "C2E",
    "from correct to incorrect reasoning": "C2E",
    "从错误推理修正回正确推理": "E2C", "从错误推理变成正确推理": "E2C", "从错误推理变为正确推理": "E2C",
    "从错误修正回正确": "E2C", "从错误修正回正确推理": "E2C", "从错误推理修改回正确推理": "E2C",
    "incorrect to correct": "E2C", "incorrect_to_correct": "E2C", "Incorrect to Correct": "E2C",
    "从错误修正回正确推理过程": "E2C",
    "from incorrect to correct": "E2C",
    "从错误推理修正回正确": "E2C"
}

def normalize_cls(c):
    return CLS_MAPPING.get(c, CLS_MAPPING.get(c.lower().strip(), "Unknown"))

# Helper: Rename groups
def rename_group(name):
    if name == "Bailian":
        return "Qwen3 baseline"
    return name

def load_analysis(path, year):
    data = []
    if not os.path.exists(path): return data
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            item = json.loads(line)
            if item['type'] == 'group_stats':
                item['year'] = year
                item['group'] = rename_group(item['group'])
                data.append(item)
    return data

summary_2024 = load_analysis(PATH_2024_ANALYSIS, 2024)
summary_2025 = load_analysis(PATH_2025_ANALYSIS, 2025)
all_summary = summary_2024 + summary_2025

# ---------------------------------------------------------------------------
# Figure 1: Robustness & Recovery Scatter Plot
# ---------------------------------------------------------------------------
def plot_figure_1(all_summary):
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    df = []
    for s in all_summary:
        core = s['core']
        df.append({
            'Group': s['group'], 'Year': s['year'],
            'Degradation Rate (C2E)': core['degradation_rate'],
            'Recovery Rate (E2C)': core['recovery_rate'],
            'Advantage Ratio': core['advantage_ratio']
        })
    df = pd.DataFrame(df).dropna(subset=['Degradation Rate (C2E)', 'Recovery Rate (E2C)'])
    
    group_colors = dict(zip(df['Group'].unique(), sns.color_palette("husl", len(df['Group'].unique()))))
    
    for ax, year in zip(axes, [2024, 2025]):
        year_df = df[df['Year'] == year]
        handles = []
        for _, row in year_df.iterrows():
            scatter = ax.scatter(
                row['Degradation Rate (C2E)'], row['Recovery Rate (E2C)'],
                s=row['Advantage Ratio'] * 200, alpha=0.7,
                marker='s', color=group_colors[row['Group']]
            )
            # Custom handle with fixed size for legend
            handles.append(plt.Line2D([0], [0], marker='s', color='w', markerfacecolor=group_colors[row['Group']], markersize=10, label=row['Group']))
        
        ax.invert_xaxis()
        ax.set_xlabel("Degradation Rate (C2E) - Lower is Better")
        ax.set_ylabel("Recovery Rate (E2C) - Higher is Better")
        ax.set_title(f"Robustness vs. Recovery Capability (AIME {year})")
        ax.legend(handles=handles, loc='upper left', frameon=True) # Legend at top-left
        
        mean_deg = year_df['Degradation Rate (C2E)'].mean()
        mean_rec = year_df['Recovery Rate (E2C)'].mean()
        if not np.isnan(mean_deg): ax.axvline(x=mean_deg, color='gray', linestyle='--', alpha=0.3)
        if not np.isnan(mean_rec): ax.axhline(y=mean_rec, color='gray', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig1_scatter_quadrants.png"), dpi=300)

# ---------------------------------------------------------------------------
# Figure 2: Temporal Recovery Trend
# ---------------------------------------------------------------------------
def load_raw_trajectories(path, year):
    trajectories = defaultdict(lambda: defaultdict(list))
    if not os.path.exists(path): return trajectories
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                item = json.loads(line)
                grp = rename_group(item['group'])
                trajectories[grp][item['problem_id']].append({
                    'block_num': item['block_num'],
                    'cls': item['result']['classification']
                })
            except: pass
    for g in trajectories:
        for p in trajectories[g]:
            trajectories[g][p].sort(key=lambda x: x['block_num'])
    return trajectories

def plot_figure_2(trajectories_2024, trajectories_2025):
    bins = 20
    def get_trend(traj_dict):
        group_points = defaultdict(list)
        for grp, probs in traj_dict.items():
            for pid, blocks in probs.items():
                N = len(blocks)
                for i, b in enumerate(blocks):
                    pos = i / N
                    # Use normalized classification logic
                    norm_c = normalize_cls(b['cls'])
                    prev_norm_c = normalize_cls(blocks[i-1]['cls']) if i > 0 else "None"
                    
                    is_recovery = 1 if norm_c == "E2C" else 0
                    is_error_context = 1 if (is_recovery or prev_norm_c in ["Incorrect", "C2E"]) else 0
                    group_points[grp].append((pos, is_recovery, is_error_context))
        results = {}
        for grp, points in group_points.items():
            df = pd.DataFrame(points, columns=['pos', 'rec', 'err_ctx'])
            df['bin'] = pd.cut(df['pos'], bins=np.linspace(0, 1, bins+1), labels=False)
            binned = df[df['err_ctx'] == 1].groupby('bin')['rec'].mean()
            results[grp] = binned
        return results

    trends_24 = get_trend(trajectories_2024)
    trends_25 = get_trend(trajectories_2025)
    
    # Figure 2a: Line Chart
    fig, axes = plt.subplots(1, 2, figsize=(16, 6), sharey=True)
    x_axis = np.linspace(2.5, 97.5, bins)
    for ax, trends, title in zip(axes, [trends_24, trends_25], ["AIME 2024", "AIME 2025"]):
        for grp, vals in trends.items():
            y = [vals.get(i, np.nan) for i in range(bins)]
            ax.plot(x_axis, y, label=grp, marker='o', markevery=[-1], markersize=8)
        ax.set_title(f"Temporal Recovery Trend ({title})")
        ax.set_xlabel("Reasoning Depth (%)")
        ax.set_ylabel("Recovery Rate")
        ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig2a_temporal_trends.png"), dpi=300)

    # Figure 2b: Late-Stage Average Recovery Rate (Last 20% / Last 4 bins)
    fig_bar, axes_bar = plt.subplots(1, 2, figsize=(16, 6))
    for ax, trends, title in zip(axes_bar, [trends_24, trends_25], ["AIME 2024", "AIME 2025"]):
        late_avg = {}
        for grp, vals in trends.items():
            # Last 20% is indices 16, 17, 18, 19
            last_4 = [vals.get(i, np.nan) for i in range(16, 20)]
            if not np.all(np.isnan(last_4)):
                late_avg[grp] = np.nanmean(last_4)
        
        if not late_avg: continue
        groups = list(late_avg.keys())
        vals = list(late_avg.values())
        sns.barplot(x=groups, y=vals, ax=ax, palette='viridis')
        ax.set_title(f"Average Recovery Rate in Late Stage ({title})")
        ax.tick_params(axis='x', rotation=45)
        min_v, max_v = min(vals), max(vals)
        margin = (max_v - min_v) * 0.2 if max_v > min_v else 0.1
        ax.set_ylim(max(0, min_v - margin), min(1.0, max_v + margin))
        
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig2b_latestage_recovery_avg.png"), dpi=300)

# ---------------------------------------------------------------------------
# Figure 3: Radar Chart (Piecewise Scaling)
# ---------------------------------------------------------------------------
def radar_scale(x):
    # Piecewise linear to magnify 0.8-1.0 by 2x
    # Total length condition: 0.8*s1 + 0.2*(2*s1) = 1.2*s1 = 1.0 => s1 = 5/6
    s1 = 5 / 6
    if x < 0.8:
        return s1 * x
    else:
        # At x=0.8, output = 0.8*s1; slope = 2*s1
        return 0.8 * s1 + 2 * s1 * (x - 0.8)

def plot_figure_3(all_summary):
    # Reordered for visual balance: [High, High, Low, High, Low] style distribution
    metrics = ['Accuracy', '1-Degradation', '1-Severity', 'Adv Ratio', 'Recovery']
    num_vars = len(metrics)
    angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
    angles += angles[:1]
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 8), subplot_kw=dict(polar=True))
    for ax, year in zip(axes, [2024, 2025]):
        year_data = [s for s in all_summary if s['year'] == year]
        if not year_data: continue

        # 1. Collect all raw values for normalization
        raw_matrix = []
        for s in year_data:
            c, sev = s['core'], s['severity']
            # Raw components
            acc = c['step_accuracy'] if not np.isnan(c['step_accuracy']) else 0
            deg_inv = 1 - c['degradation_rate'] if not np.isnan(c['degradation_rate']) else 0
            sev_inv = 1 - sev['mean'] if not np.isnan(sev['mean']) else 0
            adv = c['advantage_ratio'] if not np.isnan(c['advantage_ratio']) else 0
            rec = c['recovery_rate'] if not np.isnan(c['recovery_rate']) else 0
            raw_matrix.append([acc, deg_inv, sev_inv, adv, rec])
        
        raw_matrix = np.array(raw_matrix)
        # Find max for each column (metric) to normalize
        # We use max + a small epsilon to avoid division by zero and keep things within bounds
        max_vals = np.max(raw_matrix, axis=0)
        max_vals = np.where(max_vals == 0, 1, max_vals) # Avoid div by zero

        # 2. Plot each group
        for i, s in enumerate(year_data):
            # Normalize relative to the year's best for each metric
            norm_vals = raw_matrix[i] / max_vals
            
            # Use normalized values directly (no segmented scaling)
            vals = list(norm_vals)
            vals += vals[:1]
            
            color = sns.color_palette("husl", len(year_data))[i]
            ax.plot(angles, vals, linewidth=2, label=s['group'], color=color)
            if s['group'] == "Dynamic_Spherical":
                ax.fill(angles, vals, alpha=0.3, color=color)
        
        # Grid and Ticks
        # Since we normalized, the circles represent % of the BEST performer in that year
        grid_vals = [0.2, 0.4, 0.6, 0.8, 1.0]
        ax.set_rgrids(grid_vals, 
                      labels=[f"{int(v*100)}%" for v in grid_vals], 
                      color='gray', size=8)
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics)
        ax.set_title(f"Relative Model Capability (AIME {year})\n(Normalized to Metric Max)", size=14, y=1.1)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
    
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig3_radar_charts.png"), dpi=300)

# ---------------------------------------------------------------------------
# Figure 4: Trajectory Heatmap
# ---------------------------------------------------------------------------
def plot_figure_4(trajectories, group_name, year):
    probs = trajectories.get(group_name, {})
    if not probs: return

    # Dynamically size to actual number of problems (no blank rows)
    sorted_probs = sorted(probs.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 0)
    n_problems = min(30, len(sorted_probs))
    if n_problems == 0: return

    # Find actual max block count across all problems (trim trailing blanks)
    actual_max = min(max((len(blocks) for _, blocks in sorted_probs[:n_problems]), default=1), 50)
    max_blocks = actual_max

    grid = np.zeros((n_problems, max_blocks))
    y_labels = []
    for idx, (pid, blocks) in enumerate(sorted_probs[:n_problems]):
        y_labels.append(pid)
        for i, b in enumerate(blocks[:max_blocks]):
            norm_c = normalize_cls(b['cls'])
            if norm_c == "Correct":   grid[idx, i] = 1
            elif norm_c == "Incorrect": grid[idx, i] = 2
            elif norm_c == "C2E":      grid[idx, i] = 3
            elif norm_c == "E2C":      grid[idx, i] = 4

    plt.figure(figsize=(15, max(5, n_problems * 0.35)))
    # 0: None(White), 1: Correct(LightBlue), 2: Incorrect(Red), 3: C2E(Orange), 4: E2C(Green)
    my_cmap = ListedColormap(['#ffffff', '#add8e6', '#d73027', '#fdae61', '#1a9850'])
    # CRITICAL: fix vmin/vmax so colormap is consistent across all groups
    sns.heatmap(grid, cmap=my_cmap, vmin=0, vmax=4, cbar=False, linewidths=.3,
                yticklabels=y_labels)
    plt.title(f"Trajectory Heatmap: {group_name} ({year})")
    plt.xlabel("Block Number")
    plt.ylabel("Problem ID")

    legend_elements = [
        Patch(facecolor='#add8e6', label='Correct'),
        Patch(facecolor='#d73027', label='Incorrect'),
        Patch(facecolor='#fdae61', label='C→E (Degradation)'),
        Patch(facecolor='#1a9850', label='E→C (Correction)')
    ]
    plt.legend(handles=legend_elements, loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    plt.tight_layout(rect=[0, 0, 0.85, 1])
    plt.savefig(os.path.join(OUTPUT_DIR, f"fig4_heatmap_{group_name.replace(' ', '_')}_{year}.png"), dpi=300)
    plt.close()

# ---------------------------------------------------------------------------
# Figure 5: Persistence Bar Chart
# ---------------------------------------------------------------------------
def plot_figure_5(all_summary):
    df = pd.DataFrame([{
        'Group': s['group'], 'Year': s['year'],
        'Mean Persistence': s['persistence']['mean'], 'Max Persistence': s['persistence']['max']
    } for s in all_summary]).sort_values(by='Mean Persistence')
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    for ax, year in zip(axes, [2024, 2025]):
        year_df = df[df['Year'] == year].melt(id_vars=['Group', 'Year'], value_vars=['Mean Persistence', 'Max Persistence'], var_name='Metric', value_name='Blocks')
        if not year_df.empty:
            sns.barplot(data=year_df, x='Blocks', y='Group', hue='Metric', palette='viridis', ax=ax)
            ax.set_title(f"Error Persistence (AIME {year})")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig5_persistence_bars.png"), dpi=300)

def collect_unmapped(trajectories):
    unmapped = set()
    for grp, probs in trajectories.items():
        for pid, blocks in probs.items():
            for b in blocks:
                raw = b['cls']
                norm = normalize_cls(raw)
                if norm == "Unknown":
                    unmapped.add(raw)
    if unmapped:
        print("未识别的分类标签（需要加入字典）:")
        for item in sorted(unmapped):
            print(f"  {repr(item)}")
    return unmapped

# ---------------------------------------------------------------------------
# Figure 6: Survival Analysis (Kaplan-Meier)
# ---------------------------------------------------------------------------
def plot_figure_6(trajectories_2024, trajectories_2025):
    """
    X-axis: Error block count (t)
    Y-axis: Probability of still being in error state P(Length > t)
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # Custom Color Palette
    # Dynamic_Spherical: Bold Red, others: Muted Grays/Blues
    palette = {
        "Dynamic_Spherical": "#d62728", # Strong Red
        "SEAL_Baseline": "#7f7f7f",
        "CAA": "#9467bd",
        "Spherical_Steering": "#bcbd22",
        "Qwen3 baseline": "#17becf"
    }

    for ax, traj_dict, title in zip(axes, [trajectories_2024, trajectories_2025], ["AIME 2024", "AIME 2025"]):
        for grp, probs in traj_dict.items():
            all_runs = []
            for pid, blocks in probs.items():
                run = 0
                for b in blocks:
                    norm_c = normalize_cls(b['cls'])
                    if norm_c in ["Incorrect", "C2E"]:
                        run += 1
                    else:
                        if run > 0: all_runs.append(run)
                        run = 0
                if run > 0: all_runs.append(run)
            
            if not all_runs: continue
            
            # Start from t=1 to avoid the trivial S(0)=1.0
            max_t = min(15, max(all_runs))
            t_space = np.arange(1, max_t + 1)
            survival = []
            for t in t_space:
                s_t = sum(1 for r in all_runs if r >= t) / len(all_runs)
                survival.append(s_t)
            
            color = palette.get(grp, "gray")
            alpha = 1.0 if grp == "Dynamic_Spherical" else 0.6
            linewidth = 3 if grp == "Dynamic_Spherical" else 1.5
            
            ax.step(t_space, survival, where='post', label=grp, 
                    color=color, alpha=alpha, linewidth=linewidth)
            
        ax.set_title(f"Figure 6: Error State Survival Curve ({title})")
        ax.set_xlabel("Duration of Error (Consecutive Blocks t)")
        ax.set_ylabel("Probability of Remaining in Error S(t)")
        ax.set_ylim(0, 0.6) # Focus on the interesting range
        
        # Add annotation for better recovery
        ax.annotate("Faster Recovery\n(Desired)", xy=(1.5, 0.1), xytext=(4, 0.3),
                    arrowprops=dict(facecolor='black', arrowstyle='->'),
                    fontsize=10, fontweight='bold', color='#d62728')
        ax.legend()
        
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig6_survival_curves.png"), dpi=300)

# ---------------------------------------------------------------------------
# Figure 7: Advantage Ratio across Difficulty Tiers
# ---------------------------------------------------------------------------
def plot_figure_7(path_2024, path_2025):
    """
    X-axis: Difficulty (Easy, Medium, Hard)
    Y-axis: Relative Advantage (Scaled to Tier Max)
    """
    def load_tiers(path, year):
        tier_data = []
        if not os.path.exists(path): return tier_data
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                item = json.loads(line)
                if item['type'] == 'tier_stats':
                    for tier, grp_map in item['tiers'].items():
                        for grp, metrics in grp_map.items():
                            tier_data.append({
                                'Year': year,
                                'Tier': tier.capitalize(),
                                'Group': rename_group(grp),
                                'Adv Ratio': metrics['advantage_ratio']
                            })
        return tier_data

    raw_df = pd.DataFrame(load_tiers(path_2024, 2024) + load_tiers(path_2025, 2025))
    if raw_df.empty: return
    
    # Normalization Step: Within each (Year, Tier), scale by Max Adv Ratio
    def normalize_tier(group):
        max_val = group['Adv Ratio'].max()
        group['Relative Advantage'] = group['Adv Ratio'] / max_val if max_val > 0 else 0
        return group

    df = raw_df.groupby(['Year', 'Tier'], group_keys=False).apply(normalize_tier)
    df['Tier'] = pd.Categorical(df['Tier'], categories=['Easy', 'Medium', 'Hard'], ordered=True)
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    for ax, year in zip(axes, [2024, 2025]):
        year_df = df[df['Year'] == year]
        if year_df.empty: continue
        
        # Use a consistent palette but highlight Dynamic_Spherical
        sns.barplot(data=year_df, x='Tier', y='Relative Advantage', hue='Group', ax=ax, palette='husl')
        ax.set_title(f"Relative Dominance across Difficulty Tiers (AIME {year})")
        ax.set_ylabel("Relative Advantage (Normalized to Tier Max)")
        ax.set_ylim(0, 1.15)
        
        # Highlight our dominance in Hard tier
        ax.legend(title="Model", loc='upper left')

    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig7_tier_advantage.png"), dpi=300)

if __name__ == "__main__":
    print("Loading data...")
    traj_2024, traj_2025 = load_raw_trajectories(PATH_2024_RAW, 2024), load_raw_trajectories(PATH_2025_RAW, 2025)
    
    if all_summary:
        plot_figure_1(all_summary)
        plot_figure_2(traj_2024, traj_2025)
        plot_figure_3(all_summary)
        plot_figure_5(all_summary)
        
        # New Visualizations
        plot_figure_6(traj_2024, traj_2025)
        print("Saved Figure 6 (Survival).")
        plot_figure_7(PATH_2024_ANALYSIS, PATH_2025_ANALYSIS)
        print("Saved Figure 7 (Tier Advantage).")
        
    unmapped = collect_unmapped(traj_2024).union(collect_unmapped(traj_2025))
    for year, trajs in [(2024, traj_2024), (2025, traj_2025)]:
        for grp in trajs.keys():
            plot_figure_4(trajs, grp, year)
            print(f"Heatmap: {grp} ({year})")
    print("Done.")

import pandas as pd
import json

parquet_path = r'f:\academic\数据分析\src_api\data\aime_answer\aime_2024_problems.parquet'
df = pd.read_parquet(parquet_path)
print("Parquet Columns:", df.columns.tolist())
print("First row ID and Answer:", df.iloc[0][['ID', 'Answer']].to_dict())

jsonl_path = r'f:\academic\数据分析\src_api\data\aime_dataset\aime2024.jsonl'
with open(jsonl_path, 'r', encoding='utf-8') as f:
    first_jsonl = json.loads(f.readline())
print("JSONL First row ID:", first_jsonl.get('id'))

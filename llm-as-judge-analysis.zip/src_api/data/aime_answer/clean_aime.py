# import re

# def clean_aime_content(input_file, output_file):
#     try:
#         with open(input_file, 'r', encoding='utf-8') as f:
#             content = f.read()
#     except FileNotFoundError:
#         print(f"Error: The file '{input_file}' was not found.")
#         return

#     # 1. Fix Syntax Error: Escape the backslash correctly if you intend to remove it
#     # Or, if you meant to remove a specific tag, update the regex here.
#     content = re.sub(r'\\', '', content) 

#     # 2. Remove Video solution sections
#     # Optimized to catch the header and the content until the next major section
#     content = re.sub(r'==\s*Video solution\s*==.*?(?===|$)', '', content, flags=re.IGNORECASE | re.DOTALL)
#     content = re.sub(r'https?://\S+', '', content)

#     # 3. Remove Wiki templates {{...}} and MAA Notice
#     content = re.sub(r'\{\{.*?\}\}', '', content, flags=re.DOTALL)

#     # 4. Remove "See also" and everything after until the next Problem
#     content = re.sub(r'==\s*See also\s*==.*?(?===Problem|$)', '', content, flags=re.DOTALL | re.IGNORECASE)

#     # 5. Remove user signatures and credits (lines starting with ~ or -)
#     content = re.sub(r'^\s*[~\-].*$', '', content, flags=re.MULTILINE)

#     # 6. Normalize whitespace: reduce 3+ newlines to just 2
#     content = re.sub(r'\n{3,}', '\n\n', content)

#     # 7. Split by Problem
#     # Using a lookahead to keep the delimiter or splitting and recombining
#     parts = re.split(r'(==\s*Problem\s*==)', content, flags=re.IGNORECASE)
    
#     cleaned_output = []
#     # parts[0] is usually preamble text before the first "Problem"
#     for i in range(1, len(parts), 2):
#         header = parts[i]  # ==Problem==
#         body = parts[i+1] if i+1 < len(parts) else ""
        
#         cleaned_body = body.strip()
#         if cleaned_body:
#             # Formatting for LLM readability
#             cleaned_output.append(f"{header}\n{cleaned_body}\n" + "="*30)

#     with open(output_file, 'w', encoding='utf-8') as f:
#         f.write("\n\n".join(cleaned_output))

#     print(f"Success! Cleaned content saved to: {output_file}")

# if __name__ == "__main__":
#     # Ensure these filenames match your local environment
#     clean_aime_content('AIME_2025_Collection_Fixed.txt', 'AIME_For_LLM.txt')

# # then

# import re

# def clean_aime_content(input_file, output_file):
#     with open(input_file, 'r', encoding='utf-8') as f:
#         content = f.read()

#     # 1. 移除视频解法部分 (包含标题及其后的空白)
#     content = re.sub(r'==\s*Video [Ss]olution.*?==', '', content)

#     # 2. 移除 Asymptote 绘图代码块
#     content = re.sub(r'<asy>.*?</asy>', '', content, flags=re.DOTALL)

#     # 3. 移除多余的空行 (连续两个以上的换行符缩减为一个)
#     content = re.sub(r'\n\s*\n', '\n\n', content)

#     # 4. 移除文档末尾可能存在的冗余等号分割线
#     content = re.sub(r'={5,}', '', content)

#     # 5. 去除每一行末尾的空白字符
#     lines = [line.rstrip() for line in content.splitlines()]
    
#     # 重新组合并过滤掉连续的重复空行
#     final_output = []
#     for i, line in enumerate(lines):
#         if i > 0 and line == "" and lines[i-1] == "":
#             continue
#         final_output.append(line)

#     with open(output_file, 'w', encoding='utf-8') as f:
#         f.write("\n".join(final_output).strip())

#     print(f"清理完成！已生成: {output_file}")

# if __name__ == "__main__":
#     # 请确保 AIME_For_LLM.txt 与此脚本在同一目录下
#     clean_aime_content('AIME_For_LLM.txt', 'AIME_Cleaned_for_LLM.txt')

import re

def clean_aime_integrated(input_file, output_file):
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"错误：找不到文件 '{input_file}'")
        return

    # --- 核心清理步骤 ---

    # 1. 移除反斜杠（如果这是你的需求）
    content = content.replace('\\', '')

    # 2. 移除 Video solution 部分
    # 使用 \s* 确保兼容 ==Video Solution== 和 == Video solution ==
    # 使用 [^=]* 确保它只在遇到下一个 == 标题前停止，防止跨题目删除
    content = re.sub(r'==\s*Video\s*solution\s*==.*?(?===\s*|$)', '', content, flags=re.IGNORECASE | re.DOTALL)

    # 3. 移除 See also 部分 (同样加上 \s* 适配空格)
    content = re.sub(r'==\s*See\s*also\s*==.*?(?===\s*|$)', '', content, flags=re.IGNORECASE | re.DOTALL)

    # 4. 移除 Wiki 模板 {{...}} 和 Asymptote 代码 <asy>...</asy>
    content = re.sub(r'\{\{.*?\}\}', '', content, flags=re.DOTALL)
    content = re.sub(r'<asy>.*?</asy>', '', content, flags=re.DOTALL)
    content = re.sub(r'https?://\S+', '', content)

    # 5. 移除用户签名（以 ~ 或 - 开头的行）
    content = re.sub(r'^\s*[~\-].*$', '', content, flags=re.MULTILINE)

    # --- 切分题目 ---

    # 改进的切分正则：兼容多种空格情况，并捕获标题
    # 匹配：== (可选空格) Problem (可选数字) (可选空格) ==
    problem_pattern = r'(==\s*Problem\s*\d*\s*==)'
    parts = re.split(problem_pattern, content, flags=re.IGNORECASE)

    cleaned_output = []
    
    # 遍历切分后的结果
    # parts[0] 是第一个标题前的杂质，跳过
    for i in range(1, len(parts), 2):
        header = parts[i].strip()
        body = parts[i+1] if i+1 < len(parts) else ""
        
        # 清理正文的多余空行
        cleaned_body = re.sub(r'\n\s*\n', '\n\n', body).strip()
        
        if cleaned_body:
            # 标准化标题格式为 == Problem ==
            cleaned_output.append(f"== Problem ==\n{cleaned_body}\n" + "-"*30)

    # 保存结果
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("\n\n".join(cleaned_output))

    print(f"处理完成！原始块数较多，现在成功保留了 {len(cleaned_output)} 条题目。")
    print(f"结果已保存至: {output_file}")

if __name__ == "__main__":
    # 请确保输入文件名正确
    clean_aime_integrated('AIME_2025_Collection_Fixed.txt', 'AIME_Final_Cleaned.txt')
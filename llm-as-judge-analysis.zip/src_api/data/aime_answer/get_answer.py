# import requests
# from bs4 import BeautifulSoup
# import time
# import os

# # 基础 URL 模板
# BASE_URL = "https://artofproblemsolving.com/wiki/index.php?title=2025_AIME_{}_Problems/Problem_{}"

# headers = {
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
# }

# def get_latex_content(element):
#     """
#     将元素中的所有文本提取出来，如果是公式图片则提取其 alt 属性中的 LaTeX 代码
#     """
#     content = []
#     for node in element.descendants:
#         if node.name == 'img' and 'latex' in node.get('class', []):
#             content.append(node.get('alt', ''))
#         elif isinstance(node, str) and node.parent.name not in ['script', 'style']:
#             # 避免重复添加子节点的文本
#             if node.parent == element or node.parent.name in ['p', 'b', 'i', 'span']:
#                 if node.strip():
#                     content.append(node)
#     return "".join(content)

# def scrape_aime_problem(aime_type, prob_num):
#     url = BASE_URL.format(aime_type, prob_num)
#     print(f"正在抓取: {aime_type} Problem {prob_num}...")
    
#     try:
#         response = requests.get(url, headers=headers, timeout=10)
#         if response.status_code != 200:
#             print(f"无法访问: {url}")
#             return None
        
#         soup = BeautifulSoup(response.text, 'html.parser')
#         main_content = soup.find(id="mw-content-text")
        
#         data = {
#             "title": f"2025 AIME {aime_type} Problem {prob_num}",
#             "problem": "",
#             "solutions": []
#         }

#         # 寻找所有标题（Problem, Solution 1, etc.）
#         headlines = main_content.find_all(['h2', 'h3'])
        
#         for i, hl in enumerate(headlines):
#             text = hl.get_text().strip()
            
#             # 提取题目内容
#             if "Problem" in text and not data["problem"]:
#                 content_parts = []
#                 curr = hl.next_sibling
#                 while curr and curr.name not in ['h2', 'h3']:
#                     if curr.name in ['p', 'div']:
#                         content_parts.append(get_latex_content(curr))
#                     curr = curr.next_sibling
#                 data["problem"] = "\n".join(content_parts)

#             # 提取解析内容
#             elif "Solution" in text:
#                 # 过滤掉视频解析或仅有链接的解析
#                 if "Video" in text:
#                     continue
                
#                 content_parts = []
#                 curr = hl.next_sibling
#                 has_text = False
#                 only_link = True
                
#                 while curr and curr.name not in ['h2', 'h3']:
#                     if curr.name in ['p', 'div']:
#                         # 检查是否只有链接
#                         links = curr.find_all('a')
#                         para_text = curr.get_text(strip=True)
                        
#                         # 如果段落内有文字内容，标记为有效
#                         if para_text and not (len(links) > 0 and len(para_text) < 10):
#                             only_link = False
#                             has_text = True
                        
#                         content_parts.append(get_latex_content(curr))
#                     curr = curr.next_sibling
                
#                 if has_text and not only_link:
#                     data["solutions"].append({
#                         "name": text,
#                         "content": "\n".join(content_parts)
#                     })
                    
#         return data

#     except Exception as e:
#         print(f"处理 {url} 时出错: {e}")
#         return None

# def save_to_file(data):
#     if not data: return
#     filename = "AIME_2025_Collection.txt"
#     with open(filename, "a", encoding="utf-8") as f:
#         f.write(f"=== {data['title']} ===\n\n")
#         f.write(f"【Problem】\n{data['problem']}\n\n")
#         for sol in data['solutions']:
#             f.write(f"【{sol['name']}】\n{sol['content']}\n\n")
#         f.write("-" * 50 + "\n\n")

# # 执行主循环
# if __name__ == "__main__":
#     # 清空旧文件
#     if os.path.exists("AIME_2025_Collection.txt"):
#         os.remove("AIME_2025_Collection.txt")
        
#     for aime_type in ["I", "II"]:
#         for i in range(1, 16):
#             result = scrape_aime_problem(aime_type, i)
#             save_to_file(result)
#             # 礼貌抓取，间隔 1 秒
#             time.sleep(1)

#     print("抓取完成！内容已保存至 AIME_2025_Collection.txt")

import requests
import re
import time
import os

# 使用 &action=raw 绕过 HTML 渲染，直接获取包含完整 LaTeX 的原生代码
BASE_URL = "https://artofproblemsolving.com/wiki/index.php?title=2025_AIME_{}_Problems/Problem_{}&action=raw"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
}

def scrape_aime_problem_raw(aime_type, prob_num):
    url = BASE_URL.format(aime_type, prob_num)
    print(f"正在抓取: 2025 AIME {aime_type} Problem {prob_num}...")
    
    try:
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"  -> 无法访问 (状态码: {response.status_code})")
            return None
            
        raw_text = response.text
        lines = raw_text.split('\n')
        
        data = {
            "title": f"2025 AIME {aime_type} Problem {prob_num}",
            "problem": "",
            "solutions": []
        }
        
        # 状态机变量
        current_section_type = None  # 可选值: 'problem', 'solution', None
        current_section_name = ""
        current_content = []
        
        def save_current_section():
            """将当前收集到的文本行保存到字典中"""
            if not current_content:
                return
            text = '\n'.join(current_content).strip()
            if current_section_type == 'problem':
                data['problem'] = text
            elif current_section_type == 'solution':
                # 过滤纯视频链接解析（如果整段除开链接不到 15 个字符，即判定为无价值的视频解析）
                text_without_links = re.sub(r'https?://\S+', '', text).strip()
                if not (len(text_without_links) < 15 and 'http' in text):
                    data['solutions'].append({
                        'name': current_section_name,
                        'content': text
                    })

        for line in lines:
            # 匹配 MediaWiki 的标题语法，如 "== Problem ==" 或 "=== Solution 1 ==="
            match = re.match(r'^(=+)\s*(.*?)\s*\1$', line.strip())
            
            if match:
                title = match.group(2)
                
                # 识别题目部分
                if re.search(r'Problem', title, re.IGNORECASE):
                    save_current_section()
                    current_section_type = 'problem'
                    current_section_name = title
                    current_content = []
                    
                # 识别解答部分
                elif re.search(r'Solution', title, re.IGNORECASE):
                    save_current_section()
                    # 识别并在标题级别直接跳过视频解析
                    if re.search(r'Video', title, re.IGNORECASE):
                        current_section_type = None
                    else:
                        current_section_type = 'solution'
                        current_section_name = title
                        current_content = []
                        
                # 识别页面底部的 "See also" 或其他无关内容并停止收集
                elif re.search(r'See also', title, re.IGNORECASE) or re.search(r'See Also', title, re.IGNORECASE):
                    save_current_section()
                    current_section_type = None
                    
                else:
                    # 处理子标题（如 "=== Case 1 ==="），将其当作正常文本保留在正文中
                    if current_section_type:
                        current_content.append(line)
            else:
                # 正常文本行直接追加
                if current_section_type:
                    current_content.append(line)
                    
        # 文件末尾的最后一次保存
        save_current_section()
        
        return data

    except Exception as e:
        print(f"  -> 处理 {url} 时出错: {e}")
        return None

def save_to_file(data, filename="AIME_2025_Collection.txt"):
    if not data or not data["problem"]: 
        return
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"=== {data['title']} ===\n\n")
        f.write("【Problem】\n")
        f.write(f"{data['problem']}\n\n")
        
        for sol in data['solutions']:
            # 清理部分无用的 AoPS 格式标记（可选，让输出更干净）
            content = sol['content'].replace('~ ', '~') 
            f.write(f"【{sol['name']}】\n")
            f.write(f"{content}\n\n")
            
        f.write("=" * 80 + "\n\n")

if __name__ == "__main__":
    filename = "AIME_2025_Collection_Fixed.txt"
    if os.path.exists(filename):
        os.remove(filename)
        
    # 循环 AIME I 和 II，遍历 1-15 题   
    for aime_type in ["I", "II"]:
        for i in range(1, 16):
            result = scrape_aime_problem_raw(aime_type, i)
            if result:
                save_to_file(result, filename)
            # 礼貌性抓取，避免对 AoPS 造成压力被封 IP
            time.sleep(1)

    print(f"\n抓取完成！全 30 题的完整内容已保存至 {filename}")